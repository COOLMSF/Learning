package com.company;

public interface AAA {
    public void a();
}
