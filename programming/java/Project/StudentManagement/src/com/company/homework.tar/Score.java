package com.company;

public class Score {
    private double englishScore;
    private double chineseScore;
    private double mathScore;

    public void setChineseScore(double chineseScore) {
        this.chineseScore = chineseScore;
    }

    public void setEnglishScore(double englishScore) {
        this.englishScore = englishScore;
    }

    public void setMathScore(double mathScore) {
        this.mathScore = mathScore;
    }

    public double getChineseScore() {
        return chineseScore;
    }

    public double getEnglishScore() {
        return englishScore;
    }

    public double getMathScore() {
        return mathScore;
    }

//    public double getTotalScore() {
//    }
}
