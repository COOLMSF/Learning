// +build !debug,!release

package app

import "fyne.io/fyne"

const buildMode = fyne.BuildStandard
