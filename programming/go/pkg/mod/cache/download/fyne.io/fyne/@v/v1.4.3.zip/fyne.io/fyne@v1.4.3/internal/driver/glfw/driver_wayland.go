// +build wayland

package glfw

func init() {
	isWayland = true
}
