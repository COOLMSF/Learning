// +build release

package app

import "fyne.io/fyne"

const buildMode = fyne.BuildRelease
