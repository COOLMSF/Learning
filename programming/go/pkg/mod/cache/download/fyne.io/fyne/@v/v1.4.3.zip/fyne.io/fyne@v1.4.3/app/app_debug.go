// +build debug

package app

import "fyne.io/fyne"

const buildMode = fyne.BuildDebug
