// +build !ci
// +build !darwin no_native_menus
// +build !mobile

package glfw

func initMainMenu() {
}
