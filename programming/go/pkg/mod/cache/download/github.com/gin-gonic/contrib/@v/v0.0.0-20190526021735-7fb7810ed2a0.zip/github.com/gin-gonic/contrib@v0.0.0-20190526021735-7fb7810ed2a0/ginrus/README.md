# cache

## EOL-warning

**This package has been abandoned on 2018-10-31. Please use [gin-contrib/logger](https://github.com/gin-contrib/logger) instead.**
