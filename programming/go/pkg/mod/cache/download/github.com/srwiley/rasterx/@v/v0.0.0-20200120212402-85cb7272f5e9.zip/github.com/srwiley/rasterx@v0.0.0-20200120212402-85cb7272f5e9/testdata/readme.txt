Generated pngs from test go here.
