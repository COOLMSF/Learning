# Client

Features:
* Multi (batch) support
* Asynchronous IO

Nice-to-have:
* Simple namespacing
* Compression
* Split large keys

Performance:
* Pipelining
