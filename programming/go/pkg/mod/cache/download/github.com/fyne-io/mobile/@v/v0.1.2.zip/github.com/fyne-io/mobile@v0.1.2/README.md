# Fork of Go support for Mobile devices

This repository is a fork of the Go mobile repository that holds packages and
build tools for using Go on mobile platforms.

The primary focus of this fork is to rapidly add funcitonality required to
support the requirements of mobile support in the Fyne toolkit.
At some point it will be merged into the main repository.

To learn more about the work this is based on you can head to the wiki page
of the main project at 
[golang.org/wiki/Mobile](https://golang.org/wiki/Mobile)

