// Copyright 2014 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Package font provides platform independent access to system fonts.
package font // import "golang.org/x/mobile/exp/font"
