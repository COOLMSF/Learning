package cgopkg

import (
	_ "github.com/fyne-io/mobile/gl"
)

func Dummy() {}
