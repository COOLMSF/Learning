// +build required

// Package dummy prevents go tooling from stripping the c dependencies.
package dummy
